Recording_Travel()
{

	web_url("index.htm", 
		"URL=http://127.0.0.1:1080/WebTours/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	/* Request with GET method to URL "http://127.0.0.1:1080/favicon.ico" failed during recording. Server response : 404*/

	lr_start_transaction("LogIn");

	web_add_cookie("MSFPC=ID=0a483d9b404672469c36676c7ba16f34&CS=1&LV=201504&V=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("MC1=GUID=0a483d9b404672469c36676c7ba16f34&HASH=0a48&LV=201504&V=4&LU=1428540179491; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("A=I&I=AxUFAAAAAADiCAAAtqVUJ2dOsbwHJwijX2AXNw!!&V=4; DOMAIN=iecvlist.microsoft.com");

	lr_think_time(67);

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE10/1152921505002013023/iecompatviewlist.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(17);

	web_submit_data("login.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=115751.766869178fQfDQiVpfAiDDDDDDfHcDpiiQAf", ENDITEM, 
		"Name=username", "Value=jojo1", ENDITEM, 
		"Name=password", "Value=ban", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=login.x", "Value=33", ENDITEM, 
		"Name=login.y", "Value=7", ENDITEM, 
		LAST);

	lr_end_transaction("LogIn",LR_AUTO);

	return 0;
}