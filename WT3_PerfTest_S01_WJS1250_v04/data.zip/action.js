//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//" Script Title       : 
//"                      
//" Script Date        : Sat Feb 20 13:29:54 2016
//"                       
//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

function Action()
{
	web.url(
		{
			name : 'index.htm', 
			url : 'http://127.0.0.1:1080/WebTours/index.htm', 
			resource : 0, 
			recContentType : 'text/html', 
			referer : '', 
			snapshot : 't1.inf', 
			mode : 'HTML'
		}
	);

	web.setSocketsOption('SSL_VERSION', 'TLS1.1');

	//  Request with GET method to URL "http://127.0.0.1:1080/favicon.ico" failed during recording. Server response : 404
	lr.startTransaction('WT_T01_LandingPage');

	lr.endTransaction('WT_T01_LandingPage', lr.AUTO);

	lr.startTransaction('WT_T02_LogIn');

	lr.saveString(lr.decrypt('56c8beb1878d008e'), 'PasswordParameter');

	lr.thinkTime(54);
	web.submitData(
		{
			name : 'login.pl', 
			action : 'http://127.0.0.1:1080/cgi-bin/login.pl', 
			method : 'POST', 
			recContentType : 'text/html', 
			referer : 'http://127.0.0.1:1080/cgi-bin/nav.pl?in=home', 
			snapshot : 't2.inf', 
			mode : 'HTML', 
			itemData :  [
				{name : 'userSession', value : '117838.93236128zAzVDtApAiDDDDDDDzDzipAtAf'},
				{name : 'username', value : 'jojo'},
				{name : 'password', value : '{PasswordParameter}'},
				{name : 'JSFormSubmit', value : 'on'},
				{name : 'login.x', value : '42'},
				{name : 'login.y', value : '8'}
			]
		}
	);

	lr.endTransaction('WT_T02_LogIn', lr.AUTO);

	lr.thinkTime(36);
	lr.startTransaction('WT_T03_Search_Flights');

	web.image(
		{
			name : 'Search Flights Button', 
			alt : 'Search Flights Button', 
			snapshot : 't3.inf'
		}
	);

	//  Request with GET method to URL "http://127.0.0.1:1080/WebTours/classes/" failed during recording. Server response : 403
	//  Request with GET method to URL "http://127.0.0.1:1080/WebTours/classes/" failed during recording. Server response : 403
	lr.endTransaction('WT_T03_Search_Flights', lr.AUTO);

	lr.thinkTime(33);
	lr.startTransaction('WT_T04_Find_Flights');

	web.submitForm(
		{
			name : 'reservations.pl', 
			snapshot : 't4.inf', 
			itemData :  [
				{name : 'depart', value : 'Denver'},
				{name : 'departDate', value : '02/06/2016'},
				{name : 'arrive', value : 'Portland'},
				{name : 'returnDate', value : '02/07/2016'},
				{name : 'numPassengers', value : '1'},
				{name : 'roundtrip', value : '<OFF>'},
				{name : 'seatPref', value : 'None'},
				{name : 'seatType', value : 'Coach'},
				{name : 'findFlights.x', value : '56'},
				{name : 'findFlights.y', value : '8'}
			]
		}
	);

	lr.endTransaction('WT_T04_Find_Flights', lr.AUTO);

	lr.thinkTime(23);
	lr.startTransaction('WT_T05_Select_Flight');

	web.submitForm(
		{
			name : 'reservations.pl_2', 
			snapshot : 't5.inf', 
			itemData :  [
				{name : 'outboundFlight', value : '050;275;02/06/2016'},
				{name : 'reserveFlights.x', value : '31'},
				{name : 'reserveFlights.y', value : '9'}
			]
		}
	);

	lr.endTransaction('WT_T05_Select_Flight', lr.AUTO);

	lr.thinkTime(29);
	lr.startTransaction('WT_T06_Payment_Details');

	web.submitForm(
		{
			name : 'reservations.pl_3', 
			snapshot : 't6.inf', 
			itemData :  [
				{name : 'firstName', value : 'Jojo'},
				{name : 'lastName', value : 'Bean'},
				{name : 'address1', value : ''},
				{name : 'address2', value : ''},
				{name : 'pass1', value : 'Jojo Bean'},
				{name : 'creditCard', value : ''},
				{name : 'expDate', value : ''},
				{name : 'saveCC', value : '<OFF>'},
				{name : 'buyFlights.x', value : '64'},
				{name : 'buyFlights.y', value : '11'}
			]
		}
	);

	lr.endTransaction('WT_T06_Payment_Details', lr.AUTO);

	lr.thinkTime(27);
	lr.startTransaction('WT_T07_Check_Itinerary');

	web.image(
		{
			name : 'Itinerary Button', 
			alt : 'Itinerary Button', 
			ordinal : '1', 
			snapshot : 't7.inf'
		}
	);

	lr.endTransaction('WT_T07_Check_Itinerary', lr.AUTO);

	lr.thinkTime(43);
	lr.startTransaction('WT_T08_LogOff');

	web.image(
		{
			name : 'SignOff Button', 
			alt : 'SignOff Button', 
			ordinal : '1', 
			snapshot : 't8.inf'
		}
	);

	lr.endTransaction('WT_T08_LogOff', lr.AUTO);

	return 0;
}

